$(document).ready(function() {
    var amount = $('#amount').val();
    var currency = $('#currency').val();
    var returnurl = $('#returnurl').val();
    var description = $('#description').val();

    $.ajax({
        type: "POST",
        url: "modules/gateways/wisepay/wisepay.php",
        data: { amount: amount, currency: currency, returnurl: returnurl, description: description }
    }).done(function(response) {
        $('body').append(response);
    });
});
