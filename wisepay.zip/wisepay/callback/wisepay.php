<?php
/*
 * Wise Payment Gateway Module for WHMCS
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

require_once(dirname(__FILE__) . '/../wisepay_config.php');
require_once(dirname(__FILE__) . '/../wisepay_functions.php');

$response = wisepay_processCallback($_POST);

if ($response && isset($response['transfer']['status'])) {
    $status = $response['transfer']['status'];

    if ($status == 'completed') {
        $invoiceId = $response['transfer']['metadata']['invoice_id'];
        $transactionId = $response['transfer']['id'];

        // Update the invoice and transaction statuses in the database
        updateInvoicePaymentStatus($invoiceId, $transactionId, 'Completed');
    } else if ($status == 'pending') {
        $invoiceId = $response['transfer']['metadata']['invoice_id'];
        $transactionId = $response['transfer']['id'];

        // Update the invoice and transaction statuses in the database
        updateInvoicePaymentStatus($invoiceId, $transactionId, 'Pending');
    }
}

?>
